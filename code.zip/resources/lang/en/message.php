<?php

return [
    'Success_created' => ' Successfully Created',
    'Success_updated' => ' Successfully Updated',
    'Success_deleted' => ' Successfully Deleted',
    'Success_status' => ' Status Changed',

    'isActive' => [
        'active' => 'Active',
        'inactive' => 'Disable',
    ]
];

<?php

return [
    'Success_created' => ' Erfolgreich erstellt',
];

<!-- Bootstrap css -->
<link href="{{asset('admin/assets/plugins/bootstrap-4.3.1/css/bootstrap.min.css')}}" rel="stylesheet" />

<!-- Sidemenu Css -->
<link href="{{asset('admin/assets/css/sidemenu.css')}}" rel="stylesheet" />

<!-- Dashboard Css -->
<link href="{{asset('admin/assets/css/style.css')}}" rel="stylesheet" />
<link href="{{asset('admin/assets/css/admin-custom.css')}}" rel="stylesheet" />

<!-- c3.js Charts Plugin -->
<link href="{{asset('admin/assets/plugins/charts-c3/c3-chart.css')}}" rel="stylesheet" />

<!-- Data table css -->
<!-- <link href="{{asset('admin/assets/plugins/datatable/dataTables.bootstrap4.min.css')}}" rel="stylesheet" />
<link href="{{asset('admin/assets/plugins/datatable/jquery.dataTables.min.css')}}" rel="stylesheet" /> -->

<!-- Slect2 css -->
<link href="{{asset('admin/assets/plugins/select2/select2.min.css')}}" rel="stylesheet" />

<!-- p-scroll bar css-->
<link href="{{asset('admin/assets/plugins/pscrollbar/pscrollbar.css')}}" rel="stylesheet" />

<!---Font icons-->
<link href="{{asset('admin/assets/css/icons.css')}}" rel="stylesheet" />

<!---P-scroll Bar css -->
<link href="{{asset('admin/assets/plugins/pscrollbar/pscrollbar.css')}}" rel="stylesheet" />

<!-- Color Skin css -->
<link id="theme" rel="stylesheet" type="text/css" media="all" href="{{asset('admin/assets/color-skins/color7.css')}}" />



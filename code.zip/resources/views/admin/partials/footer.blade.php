<footer class="footer">
    <div class="container">
        <!-- <div class="row align-items-center flex-row-reverse">
            <div class="col-lg-12 col-sm-12 text-center">
                Copyright © 2021 <a href="#" class="fs-14 text-primary">Cplus Soft</a>. Designed by <a href="#"
                    class="fs-14 text-primary"> Cplus Soft Pvt.Ltd </a>All rights reserved.
            </div>
        </div> -->
    </div>
</footer>

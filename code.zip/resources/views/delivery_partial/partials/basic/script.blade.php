<!-- Back to top -->
<a href="#top" id="back-to-top"><i class="fa fa-rocket"></i></a>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>

<!-- JQuery js-->
<script src="{{ asset('admin/assets/js/jquery-3.2.1.min.js') }}"></script>

<!-- Bootstrap js -->
<script src="{{ asset('admin/assets/plugins/bootstrap-4.3.1/js/popper.min.js') }}"></script>
<script src="{{ asset('admin/assets/plugins/bootstrap-4.3.1/js/bootstrap.min.js') }}"></script>

<!--JQuery Sparkline Js-->
<script src="{{ asset('admin/assets/js/jquery.sparkline.min.js') }}"></script>

<!-- Circle Progress Js-->
<script src="{{ asset('admin/assets/js/circle-progress.min.js') }}"></script>

<!-- Star Rating Js-->
<script src="{{ asset('admin/assets/plugins/rating/jquery.rating-stars.js') }}"></script>

<!-- Fullside-menu Js-->
<script src="{{ asset('admin/assets/plugins/sidemenu/sidemenu.js') }}"></script>

<!-- Data tables -->
<!-- <script src="{{ asset('admin/assets/plugins/datatable/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('admin/assets/plugins/datatable/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('admin/assets/js/datatable.js') }}"></script> -->

<!-- Select2 js -->
<script src="{{ asset('admin/assets/plugins/select2/select2.full.min.js') }}"></script>
<script src="{{ asset('admin/assets/js/select2.js') }}"></script>

<!-- p-scroll bar Js-->
<script src="{{ asset('admin/assets/plugins/pscrollbar/pscrollbar.js') }}"></script>
<script src="{{ asset('admin/assets/plugins/pscrollbar/pscroll.js') }}"></script>

<!--Counters -->
<script src="{{ asset('admin/assets/plugins/counters/counterup.min.js') }}"></script>
<script src="{{ asset('admin/assets/plugins/counters/waypoints.min.js') }}"></script>


<!-- Inline js -->
<script src="{{ asset('admin/assets/js/formelements.js') }}"></script>

<!-- file uploads js -->
<script src="{{ asset('admin/assets/plugins/fileuploads/js/fileupload.js') }}"></script>


<!-- Custom Js-->
<script src="{{ asset('admin/assets/js/admin-custom.js') }}"></script>

<!-- Sweet alert Plugin -->
<script src="{{ asset('admin/assets/plugins/sweet-alert/sweetalert.min.js') }}"></script>
<script src="{{ asset('admin/assets/js/sweet-alert.js') }}"></script>


<link rel="stylesheet" type="text/css"
    href="https://cdn.jsdelivr.net/gh/kenwheeler/slick@1.8.1/slick/slick-theme.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
